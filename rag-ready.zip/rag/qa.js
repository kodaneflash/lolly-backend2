import { ingestDocuments } from "./ingest.js";
import vectorStore from "./store.js";
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function answerWithRAG(userMessage) {
  await ingestDocuments();

  const relevantDocs = await vectorStore.similaritySearch(userMessage, 4);
  const context = relevantDocs.map(doc => doc.pageContent).join("\n---\n");

  const completion = await openai.chat.completions.create({
    model: "gpt-4-turbo",
    messages: [
      {
        role: "system",
        content: `
Tu es un assistant expert de l'entreprise www.neemba.com.
Tu t'appuies sur le contexte suivant pour répondre :

${context}

Tu réponds uniquement en français.
Formate la réponse comme suit :
{
  "messages": [
    {
      "text": "...",
      "facialExpression": "...",
      "animation": "...",
      "source": "...",
      "image": "..."
    }
  ]
}
        `.trim()
      },
      { role: "user", content: userMessage }
    ],
    response_format: { type: "json_object" }
  });

  return JSON.parse(completion.choices[0].message.content);
}
