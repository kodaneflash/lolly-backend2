import fs from "fs";
import path from "path";
import pdfParse from "pdf-parse";
import vectorStore from "./store.js";

async function parseFile(filePath) {
  const ext = path.extname(filePath);
  const content = fs.readFileSync(filePath);
  if (ext === ".pdf") {
    const pdfData = await pdfParse(content);
    return pdfData.text;
  } else {
    return content.toString("utf8");
  }
}

export async function ingestDocuments(directory = "rag_project/docs") {
  const files = fs.readdirSync(directory);
  for (const file of files) {
    const fullPath = path.resolve(directory, file);
    const content = await parseFile(fullPath);
    const chunks = content.split("\n\n").filter(p => p.length > 30);
    await vectorStore.addDocuments(
      chunks.map(chunk => ({
        pageContent: chunk,
        metadata: { source: file },
      }))
    );
    console.log(`✅ Document "${file}" indexé (${chunks.length} chunks)`);
  }
}
